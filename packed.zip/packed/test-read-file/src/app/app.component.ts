import { Component } from '@angular/core';
import { DiaryService } from './service/diary.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  recordsList: string [] = [];

  constructor(private diaryService: DiaryService) {}

  initRecordList() {
    this.diaryService.getAllecords().subscribe(data => {
      this.recordsList = data;
    }, error => {
      console.log(error);
    });
  }

}
