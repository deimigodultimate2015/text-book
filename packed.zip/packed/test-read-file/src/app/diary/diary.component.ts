import { RecordLine } from './../entity/record-line';
import { Component, OnInit } from '@angular/core';
import { DiaryService } from '../service/diary.service';

@Component({
  selector: 'app-diary',
  templateUrl: './diary.component.html',
  styleUrls: ['./diary.component.scss']
})
export class DiaryComponent implements OnInit {

  deleted = false;

  recordsList: string [] = [];
  recordContent: RecordLine[] = [];
  currentRecord = '';

  constructor(private diaryService: DiaryService) {}

  ngOnInit(): void {
    this.initRecordList();
  }

  initRecordList() {
    this.diaryService.getAllecords().subscribe(data => {
      this.recordsList = data;
    }, error => {
      console.log(error);
    });
  }

  openRecord(recordFile: string) {
    this.currentRecord = recordFile;
    this.diaryService.getRecordsContent(recordFile).subscribe(data => {
      this.convertRawContentToDynamic(data.content);
    }, error => {
      console.log(error);
    });
  }

  uploadRecord(event) {
    for ( const file of event) {
      this.diaryService.importRecord(file).subscribe(data => {
        this.initRecordList();
      }, error => {
        console.log(error);
      });
    }
  }

  letDeletedFromBegin() {
    this.deleted = false;
  }

  convertRawContentToDynamic(content) {
    this.recordContent = [];
    for ( const line of content.split('\n')) {
      if (line) {
        const recordLineTS = new RecordLine();
        recordLineTS.line = line.substring(10, line.length);
        recordLineTS.time = line.substring(0, 9);
        this.recordContent.push(recordLineTS);
      }
    }
  }

  deleteCurrentRecord(clientInputDeleteMagicCode: string) {
    if (clientInputDeleteMagicCode === this.currentRecord) {
      this.diaryService.deleteRecord(this.currentRecord).subscribe(data => {
        this.deleted = true;
        this.initRecordList();
        this.clear();
      }, error => {
        console.log(error);
      });
    }
  }

  clear() {
    this.recordContent = [];
    this.currentRecord = '';
  }
}
