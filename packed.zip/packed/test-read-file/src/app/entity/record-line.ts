export class RecordLine {
    time: string;
    line: string;
}
