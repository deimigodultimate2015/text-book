import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { URI_BASE_URL } from '../constant/URI_BASE_URL';

@Injectable({
  providedIn: 'root'
})
export class DiaryService {

  constructor(private http: HttpClient) { }

  public getAllecords(): Observable<any> {
    return this.http.get(`${URI_BASE_URL}/api/diary/records`);
  }

  public getRecordsContent(recordFile: string): Observable<any> {
    return this.http.get<any>(`${URI_BASE_URL}/api/diary/record/${recordFile}`);
  }

  public importRecord(file: any): Observable<any> {
    const formData = new FormData();
    formData.append('record', file);
    return this.http.post(`${URI_BASE_URL}/api/diary/record`, formData);
  }

  public deleteRecord(title: string): Observable<any> {
    return this.http.delete(`${URI_BASE_URL}/api/diary/record/${title}`);
  }
}
